package deus_sdet.assignment;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FlipkartPages {
	
WebDriver driver;
	
	public FlipkartPages(WebDriver driver1) {
		this.driver=driver1;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(how=How.XPATH, using="//div[@class='_3Njdz7']/button") WebElement popUpCloseButton;
	
	@FindBy(how=How.XPATH, using="//div[@class='O8ZS_U']/input") WebElement searchTextBox;
	
	@FindBy(how=How.CLASS_NAME, using="vh79eN") WebElement searchButton;
	
	@FindBy(how=How.XPATH, using="//div[@class='col col-7-12']/div[1]") WebElement iphoneSearchResult;
	
	@FindBy(how=How.XPATH, using="//div[@class='_1uv9Cb']/div") WebElement iphonePriceFlipkart;
	
	
	public void navigateToFlipkart() {
		  driver.get("https://www.flipkart.com/");
		  driver.manage().window().maximize();
		  popUpCloseButton.click();
	}
	
	public void performSearch() {
		searchTextBox.sendKeys("iPhone XR (64GB) - Yellow");
		  
		searchButton.click();
	}
	
	public void navigateToSRP() {
		WebDriverWait wait= new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(iphoneSearchResult));
		iphoneSearchResult.click();
	}
	
	public void switchToWindow1() {
		String parentWindow=driver.getWindowHandle();
		  Set<String> windows=driver.getWindowHandles();
		  
		  for (String string : windows) 
		  {
			if (string.equals(parentWindow)==false) 
			{
				driver.switchTo().window(string);
				System.out.println("Window Swithched");
				break;
			}
		}
	}
	
	public int getPhonePrice() {

		  String phoenePrice=iphonePriceFlipkart.getText();
		  
		  String flipkartPrice1="";
		  
		  for (int i = 0; i < phoenePrice.length(); i++) {
			  int char2;
			  char2=phoenePrice.charAt(i);
			if ((char2>47) && (char2<58)) {
				flipkartPrice1=flipkartPrice1+(char)char2;
			}
		}
		  
		  int flipkartPhonePrice=Integer.parseInt(flipkartPrice1);
		  System.out.println("iPhone XR (64GB) - Yellow Price at Amazon is:: "+flipkartPhonePrice);
		  
		  return flipkartPhonePrice;
	}

}
