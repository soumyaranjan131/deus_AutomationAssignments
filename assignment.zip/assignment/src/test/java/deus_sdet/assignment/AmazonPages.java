package deus_sdet.assignment;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AmazonPages {
	
	WebDriver driver;
	
	public AmazonPages(WebDriver driver1) {
		this.driver=driver1;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(how=How.ID,using="twotabsearchtextbox") WebElement searchTextBox;
	
	@FindBy(how=How.XPATH,using="//div[@class='nav-search-submit nav-sprite']/input") WebElement searchButton;
	
	@FindBy(how=How.XPATH,using="//span[@class='a-size-medium a-color-base a-text-normal'][1]") WebElement searchResult1st;
	
	
	@FindBy(how=How.ID,using="priceblock_ourprice") WebElement iphonePriceAmazon;
	
	public void navigateToAmazon() {
		driver.get("https://www.amazon.in/");
		 driver.manage().window().maximize();
	}
	
	public void performSearch() {
		  searchTextBox.clear();
		  
		  searchTextBox.sendKeys("iPhone XR (64GB) - Yellow");
		  
		  searchButton.click();
	}
	
	public void navigateToSRP() {
		searchResult1st.click();
	}
	
	public void switchToWindow1() {
		String parentWindow=driver.getWindowHandle();
		  Set<String> windows=driver.getWindowHandles();
		  
		  for (String string : windows) 
		  {
			if (string.equals(parentWindow)==false) 
			{
				driver.switchTo().window(string);
				System.out.println("Window Swithched");
				break;
			}
		}
	}
	
	
	public int getPhonePrice() {
		String amazonP=iphonePriceAmazon.getText();
		  String amazonPrice1="";
		  
		  for (int i = 0; i < amazonP.length(); i++) {
			  int char1;
			  char1=amazonP.charAt(i);
			if ((char1>47) && (char1<58)) {
				amazonPrice1=amazonPrice1+(char)char1;
			}
		}
		  
		  int amazonPrice=Integer.parseInt(amazonPrice1);
		  amazonPrice=amazonPrice/100;
		  System.out.println("iPhone XR (64GB) - Yellow Price at Amazon is:: "+amazonPrice);
		  return amazonPrice;
	}	

}
