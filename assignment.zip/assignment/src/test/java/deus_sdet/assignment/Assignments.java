package deus_sdet.assignment;


import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import deus_sdet.assignment.TripAdvisorPages;

public class Assignments {
   WebDriver driver;
  
  @Test(enabled=true)
  public void assignment1() throws InterruptedException {
	  
	  
	  AmazonPages ap= PageFactory.initElements(driver, AmazonPages.class);
	  ap.navigateToAmazon();
	  
	  ap.performSearch();
	  
	  ap.navigateToSRP();
	  
	  ap.switchToWindow1();
	  
	  int amazonPhonePrice=ap.getPhonePrice();
	  
	  driver.quit();
	  
	  driver=new ChromeDriver();

	  FlipkartPages fp= PageFactory.initElements(driver, FlipkartPages.class);
	  
	  fp.navigateToFlipkart();
	  fp.performSearch();
	  fp.navigateToSRP();
	  fp.switchToWindow1();
	  int flipkartPhonePrice=fp.getPhonePrice();
	  
	  if(flipkartPhonePrice>amazonPhonePrice) {
		  System.out.println("Amazon has less Phone Price");
	  }
	  else if(flipkartPhonePrice<amazonPhonePrice) {
		  System.out.println("Flipkart has less Phone Price");
	  }
	  else {
		  System.out.println("Amazon and Flipkart both have same Price");
	  }	   
  }
  
  
  @Test(enabled=true)
  public void assignment2() throws InterruptedException {
	  driver.get("https://www.tripadvisor.in/");
	  driver.manage().window().maximize();
	  TripAdvisorPages tp= PageFactory.initElements(driver, TripAdvisorPages.class);
	  
	  tp.performSearch();
	  
	  tp.navigateToSearchResult();
	  
	  tp.switchWindow1();
	  
	  tp.navigateToReviewPage();
	  
	  tp.switchWindow2();
	  
	  tp.performRating();
	  
	  tp.performReview();
	   
  }
  
  
  
  
  @BeforeMethod
  public void beforeMethod() {
	    String chromeExePath="E:\\Workspace\\FIles\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",chromeExePath);
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver, 20);
  }

  @AfterMethod
  public void afterMethod() {
	  
  }

}
