package deus_sdet.assignment;

import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TripAdvisorPages {
	WebDriver driver;
	
	
	
	String parentWindow;
	
	@FindBy(how=How.CLASS_NAME,using="brand-global-nav-action-search-Search__label--3PRUD") 
	WebElement searchButton;
	
	@FindBy(how=How.ID,using="mainSearch") 
	WebElement mainSearchTB;
	
	@FindBy(how=How.ID,using="SEARCH_BUTTON_CONTENT") 
	WebElement searchSubmitButton;
	
	@FindBy(how=How.XPATH,using="//body[@id='BODY_BLOCK_JQUERY_REFLOW']//div[@class='result-title'][1]/span")
	WebElement firstSearchResult;
	
	@FindBy(how=How.XPATH,using="//div[@id='component_12']//div[@class='hotels-community-content-common-ContextualCTA__currentOption--3Wd5D']/a")
	WebElement writeReviewButton;
	
	@FindBy(how=How.XPATH,using="//span[@id='bubble_rating'] ")
	WebElement rating1;
	
	@FindBy(how=How.ID,using="ReviewTitle")
	WebElement reviewTitleTextBox;
	
	@FindBy(how=How.ID,using="ReviewText")
	WebElement reviewTextBox;
	
	@FindBy(how=How.ID,using="qid11_bubbles")
	WebElement roomRating;
	
	@FindBy(how=How.ID,using="qid12_bubbles")
	WebElement serviceRating;
	
	@FindBy(how=How.ID,using="qid13_bubbles")
	WebElement valueRating;
	
	@FindBy(how=How.ID,using="noFraud")
	WebElement submitCheckBox;
	
	public void performSearch() {
		searchButton.click();
		mainSearchTB.sendKeys("Club Mahindra");
		searchSubmitButton.click();
	}
	
	public void navigateToSearchResult() {
		firstSearchResult.click();
	}
	
	public void switchWindow1() {
		parentWindow=driver.getWindowHandle();
		Set<String> windows=driver.getWindowHandles();
	 
		  for (String string : windows) 
		  {
			if (string.equals(parentWindow)==false) 
			{
				driver.switchTo().window(string);
				break;
			}
		}
	}
	
	public void navigateToReviewPage() {
		
		WebDriverWait wait=new WebDriverWait(driver, 20);

		  boolean result=false;
		  int attempts = 0;
		    while(attempts < 2) {
		        try {
		        	wait.until(ExpectedConditions.visibilityOf(writeReviewButton));
		        	writeReviewButton.click();
		            result = true;
		            break;
		        } catch(Exception e) {
		        	System.out.println(e);
		        }
		        attempts++;
		    }
	}
	
	public void switchWindow2() {
		String parentWindow1=driver.getWindowHandle();
		  Set<String> windows1=driver.getWindowHandles();
		  for (String string : windows1) 
		  {
			if ((string.equals(parentWindow1)==false)&& (string.equals(parentWindow)==false))
			{
				driver.switchTo().window(string);
				break;
			}
		}   
	}
	
	public void performRating() throws InterruptedException {
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(rating1));
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		  for (int i = 1; i < 6; i++) { 
			  String str="document.getElementById('bubble_rating').setAttribute('class', 'ui_bubble_rating fl bubble_"+(i*10)+"')";
			  js.executeScript(str);
			  Thread.sleep(500);
			
		}	  
		  rating1.click();
	}
	
	public void performReview() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		  reviewTitleTextBox.sendKeys("Excelent");
		  reviewTextBox.sendKeys("We enjoyed allot in madikeri rooms very need n clean... Food was tasty... Especially new celebration was really amazing.. Thank u for lots of activities to enjoy... we liked the food at green cardamom it was yummy.... we went sightseeing at madikeri.... great holiday.... thanks for the wonderful hospitality from staff.... great team");
		  
		  serviceRating.click();
		  
		  js.executeScript("window.scrollBy(0,400)");
		  
		  submitCheckBox.click();
		
	}

	public TripAdvisorPages(WebDriver driver1) {
		this.driver=driver1;
		PageFactory.initElements(driver, this);
		
	}

}
